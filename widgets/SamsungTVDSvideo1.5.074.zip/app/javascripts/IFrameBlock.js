var IFrameBlock={HandleKeyDown:function(a){},InternalNavigator:function(a){},LeaveToNavigator:function(a){},EnterFromNavigator:function(a){}};
